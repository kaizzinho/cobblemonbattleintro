package com.kaizzinho.battleintroduction.mixin.client;

import net.fabricmc.loader.api.FabricLoader;
import org.objectweb.asm.tree.ClassNode;
import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;

import java.util.List;
import java.util.Set;


// only load addon mixins when the target mod exists
public final class BattleIntroductionMixinPlugin implements IMixinConfigPlugin {

    private static final String BATTLE_EXTRAS_MOD_ID =
            "cobblemon-battle-extras";

    private static final String BATTLE_EXTRAS_MIXIN =
            "com.kaizzinho.battleintroduction.mixin.client."
                    + "BattleExtrasScreenRenderMixin";

    @Override
    public void onLoad(String mixinPackage) {

    }

    @Override
    public String getRefMapperConfig() {
        return null;
    }

    @Override
    public boolean shouldApplyMixin(
            String targetClassName,
            String mixinClassName
    ) {
        if (BATTLE_EXTRAS_MIXIN.equals(mixinClassName)) {
            return FabricLoader.getInstance()
                    .isModLoaded(BATTLE_EXTRAS_MOD_ID);
        }

        return true;
    }

    @Override
    public void acceptTargets(
            Set<String> myTargets,
            Set<String> otherTargets
    ) {

    }

    @Override
    public List<String> getMixins() {
        return null;
    }

    @Override
    public void preApply(
            String targetClassName,
            ClassNode targetClass,
            String mixinClassName,
            IMixinInfo mixinInfo
    ) {

    }

    @Override
    public void postApply(
            String targetClassName,
            ClassNode targetClass,
            String mixinClassName,
            IMixinInfo mixinInfo
    ) {

    }
}
